package com.farouk.bankaccountservice.enums;

public enum AccountType {
    CURRENT_ACCOUNT, SAVING_ACCOUNT
}
